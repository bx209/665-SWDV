import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-more',
  templateUrl: './edit-more.page.html',
  styleUrls: ['./edit-more.page.scss'],
})
export class EditMorePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
