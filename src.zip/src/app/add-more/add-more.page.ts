import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-more',
  templateUrl: './add-more.page.html',
  styleUrls: ['./add-more.page.scss'],
})
export class AddMorePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
