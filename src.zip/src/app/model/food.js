const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Song = new Schema({
  food_name: {
    type: String
  },
  type: {
    type: String
  }
}, {
  collection: 'foods'
})

module.exports = mongoose.model('foods', Song)